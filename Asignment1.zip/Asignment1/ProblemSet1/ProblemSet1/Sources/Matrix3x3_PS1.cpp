//
//  Matrix3x3_PS1.cpp
//  ProblemSet1
//
//  Created by Luan Nguyen on 20/3/2024.
//

#include <stdio.h>
#include "Matrix3x3.h"
#include <cassert>
#include <cmath>



// Multiply 2 Matrices
Matrix3x3 Matrix3x3::operator*(const Matrix3x3& aOther) const noexcept{
    // Create 3 Rows for the matrix
    Vector3D Row1( row(0).dot(aOther.column(0)),
                   row(0).dot(aOther.column(1)),
                   row(0).dot(aOther.column(2))
                  );
    Vector3D Row2( row(1).dot(aOther.column(0)),
                   row(1).dot(aOther.column(1)),
                   row(1).dot(aOther.column(2))
                   );
    Vector3D Row3( row(2).dot(aOther.column(0)),
                   row(2).dot(aOther.column(1)),
                   row(2).dot(aOther.column(2))
                  );
    // Return the created matrix
    return Matrix3x3(Row1, Row2, Row3);
            
}

// Determine of a Matrix
float Matrix3x3::det() const noexcept{
    float result = 0.0f;
    result += row(0)[0] * (row(1)[1]*row(2)[2] - row(1)[2]*row(2)[1]);
    result -= row(0)[1] * (row(1)[0]*row(2)[2] - row(1)[2]*row(2)[0]);
    result += row(0)[2] * (row(1)[0]*row(2)[1] - row(1)[1]*row(2)[0]);
    
    return result;
}

// Transpose the Matrix
Matrix3x3 Matrix3x3::transpose() const noexcept{
    
    return Matrix3x3(column(0),column(1),column(2));
}


// Check of the Matrix is invertible
bool Matrix3x3::hasInverse() const noexcept{
    if (det() == 0.0f)
        return false;
    else
        return true;
}


// Inverse of a matrix

Matrix3x3 Matrix3x3::inverse() const noexcept{
    assert(det()!=0);
    
    Vector3D Row1 ( row(1)[1] * row(2)[2] - row(1)[2] * row(2)[1],
                    row(0)[2] * row(2)[1] - row(0)[1] * row(2)[2],
                    row(0)[1] * row(1)[2] - row(0)[2] * row(1)[1]);
    
    Vector3D Row2 ( row(1)[2] * row(2)[0] - row(1)[0] * row(2)[2],
                    row(0)[0] * row(2)[2] - row(0)[2] * row(2)[0],
                    row(0)[2] * row(1)[0] - row(0)[0] * row(1)[2]);
    
    Vector3D Row3 ( row(1)[0] * row(2)[1] - row(1)[1] * row(2)[0],
                    row(0)[1] * row(2)[0] - row(0)[0] * row(2)[1],
                    row(0)[0] * row(1)[1] - row(0)[1] * row(1)[0]);
    
    return Matrix3x3(Row1, Row2, Row3)* (1/det());

    }

std::ostream& operator<<(std::ostream& aOStream, const Matrix3x3& aMatrix) {
    return aOStream << "[" << aMatrix.row(0).toString()
        << "," << aMatrix.row(1).toString()
        << "," << aMatrix.row(2).toString() << "]";
}
