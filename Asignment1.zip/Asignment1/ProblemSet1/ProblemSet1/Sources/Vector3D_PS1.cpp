//
//  Vector3D_PS1.cpp
//  ProblemSet1
//
//  Created by Luan Nguyen on 19/3/2024.
//


#include "Vector3D.h"

#include <cassert>
#include <cmath>
#include <sstream>


// Problem 1 - Implement ToString extention
std::string Vector3D::toString() const noexcept{
    
    // Create a string stream for constructing the string representation
    std::stringstream ss;
    
    //Round the components to four decimal
    ss << "[" << std::round(fBaseVector.x() * 10000.0f) / 10000.0f << ", "
    << std::round(fBaseVector.y() * 10000.0f) / 10000.0f << ", "
    << std::round(fW * 10000.0f) / 10000.0f << "]";
    
    // Convert to string
    return ss.str();
}
