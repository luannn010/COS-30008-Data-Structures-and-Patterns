//
//  Polygon_PS1.cpp
// Polygon_PS1.cpp
//
//  Created by Luan Nguyen on 20/3/2024.
//

#include <stdio.h>
#include "Polygon.h"



float Polygon::getSignedArea() const noexcept {
    float result = 0.0f; // Initialize the result variable to store the signed area
    for (int i = 0; i < fNumberOfVertices; i++) {
        int j = (i + 1) % fNumberOfVertices; // Get the index of the next vertex using modulus to handle wrapping
        // Calculate the area of the trapezoid formed by the current edge and the x-axis
        float area = (fVertices[i].x() + fVertices[j].x()) * (fVertices[j].y() - fVertices[i].y()) / 2.0f;
        // Add the area to the result
        result += area;
    }
    return result; // Return the signed area of the polygon
}



// Transform the current polygon by applying a 3x3 transformation matrix
// to each vertex, resulting in a new transformed polygon.
Polygon Polygon::transform(const Matrix3x3& aMatrix) const noexcept {
    // Create a copy of the current polygon
    Polygon result = *this;

    // Iterate through each vertex of the polygon
    for (int i = 0; i < fNumberOfVertices; i++) {
        // Transform the current vertex using the transformation matrix
        // and store the result in a temporary Vector3D object.
        Vector3D TempVec = Vector3D(aMatrix * fVertices[i]);

        // Convert the resulting 3D vector to a 2D vector by discarding the z-coordinate,
        // and assign it to the corresponding vertex of the transformed polygon.
        result.fVertices[i] = static_cast<Vector2D>(TempVec);
    }

    // Return the transformed polygon
    return result;
}

